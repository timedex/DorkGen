﻿
namespace doork
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.materialContextMenuStrip1 = new MaterialSkin.Controls.MaterialContextMenuStrip();
            this.materialContextMenuStrip2 = new MaterialSkin.Controls.MaterialContextMenuStrip();
            this.bttngenerar = new MaterialSkin.Controls.MaterialFlatButton();
            this.lblgen = new MaterialSkin.Controls.MaterialLabel();
            this.SuspendLayout();
            // 
            // materialContextMenuStrip1
            // 
            this.materialContextMenuStrip1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.materialContextMenuStrip1.Depth = 0;
            this.materialContextMenuStrip1.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialContextMenuStrip1.Name = "materialContextMenuStrip1";
            this.materialContextMenuStrip1.Size = new System.Drawing.Size(61, 4);
            // 
            // materialContextMenuStrip2
            // 
            this.materialContextMenuStrip2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.materialContextMenuStrip2.Depth = 0;
            this.materialContextMenuStrip2.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialContextMenuStrip2.Name = "materialContextMenuStrip2";
            this.materialContextMenuStrip2.Size = new System.Drawing.Size(61, 4);
            // 
            // bttngenerar
            // 
            this.bttngenerar.AutoSize = true;
            this.bttngenerar.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.bttngenerar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.bttngenerar.Depth = 0;
            this.bttngenerar.Location = new System.Drawing.Point(58, 115);
            this.bttngenerar.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.bttngenerar.MouseState = MaterialSkin.MouseState.HOVER;
            this.bttngenerar.Name = "bttngenerar";
            this.bttngenerar.Primary = false;
            this.bttngenerar.Size = new System.Drawing.Size(73, 36);
            this.bttngenerar.TabIndex = 2;
            this.bttngenerar.Text = "Generar";
            this.bttngenerar.UseVisualStyleBackColor = false;
            this.bttngenerar.Click += new System.EventHandler(this.materialFlatButton1_Click_1);
            // 
            // lblgen
            // 
            this.lblgen.AutoSize = true;
            this.lblgen.BackColor = System.Drawing.Color.Transparent;
            this.lblgen.Depth = 0;
            this.lblgen.Font = new System.Drawing.Font("Roboto", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblgen.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lblgen.Location = new System.Drawing.Point(198, 123);
            this.lblgen.MouseState = MaterialSkin.MouseState.HOVER;
            this.lblgen.Name = "lblgen";
            this.lblgen.Size = new System.Drawing.Size(0, 19);
            this.lblgen.TabIndex = 3;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(684, 241);
            this.Controls.Add(this.lblgen);
            this.Controls.Add(this.bttngenerar);
            this.ForeColor = System.Drawing.SystemColors.ControlText;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.ShowIcon = false;
            this.Sizable = false;
            this.Text = "By nothing";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private MaterialSkin.Controls.MaterialContextMenuStrip materialContextMenuStrip1;
        private MaterialSkin.Controls.MaterialContextMenuStrip materialContextMenuStrip2;
        private MaterialSkin.Controls.MaterialFlatButton BtonGenerar;
        private MaterialSkin.Controls.MaterialFlatButton bttngenerar;
        private MaterialSkin.Controls.MaterialLabel lblgen;
    }
}

